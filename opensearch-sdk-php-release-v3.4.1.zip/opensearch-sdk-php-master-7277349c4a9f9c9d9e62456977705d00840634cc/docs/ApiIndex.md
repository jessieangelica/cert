API Index
=========

* OpenSearch
    * OpenSearch\Client
        * [DataCollectionClient](OpenSearch-Client-DataCollectionClient.md)

